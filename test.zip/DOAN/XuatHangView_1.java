/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package DOAN;

import static DOAN.XuatHangView.name;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Locale;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.math3.random.JDKRandomGenerator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author DELL
 */
public class XuatHangView_1 extends javax.swing.JFrame {
    DefaultTableModel model;
     DefaultTableModel model1;
     public static String name;
     public long Tongtien;
    /**
     * Creates new form NhapHangView
     */
    public XuatHangView_1(String name) {
        this.name = name;
        initComponents();
        String[] header = {"Mã hàng", "Size", "Màu sắc", "Hãng sản xuất", "Giá", "Loại hàng", "Số lượng"};
        String[] header1 = {"Mã hàng", "Size", "Màu sắc", "Hãng sản xuất", "Giá", "Loại hàng", "Số lượng","Thành tiền"};
        
        model=new DefaultTableModel(header1,0);
        model1=new DefaultTableModel(header, 0);
        tblXuatHang.setModel(model);
        tblKho.setModel(model1);
        initLoadDataToJtable();
        initLoadDataToJtableKho();
        this.setLocationRelativeTo(null);
        JPDoiTK.setVisible(false);
        JOptionPane.showMessageDialog(this, "Ban hay nhap ma hang truoc khi thuc hien cac thao tac Them, Xoa, Sua");
    }
    
    public void initLoadDataToJtable(){
        Tongtien= 0;
        model.setRowCount(0);//xoa toan bo cac dong hien ton tai tren ban 
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try  {
            Connection con = DriverManager.getConnection(connectionUrl); 
            Statement stmt = con.createStatement();
            String SQL = "SELECT * FROM XuatHang";// dat cac chuoi leng vao bien SQL
            ResultSet rs = stmt.executeQuery(SQL);//goi rs truy van vao database
            //thuc hien chuyen chuoi so thanh tien co dau ngat cho de nhin
               
                Locale localeVN = new Locale("vi", "VN");
                // Locale là đối tượng đại diện duy nhất cho các ngôn ngữ và quốc gia, khu vực
                // khác nhau trên toàn thế giới 
                // trong đó "vi" là ngôn ngữ và "VN" là tên quốc gia.
                NumberFormat currencyVN = NumberFormat.getCurrencyInstance(localeVN);
                // tạo 1 NumberFormat để định dạng số theo tiêu chuẩn của Việt Nam
            // Iterate through the data in the result set and display it.
            while (rs.next()) {
                Long thanhtien = Long.valueOf(rs.getString("Total"));
                Long gia = Long.valueOf(rs.getString("Price"));
                String gia_str = currencyVN.format(gia);
                String thanhtien_str = currencyVN.format(thanhtien);
                Tongtien = Tongtien+thanhtien;
                
                
                String[] row= new String[]{rs.getString("ComodityCode"),
                                           rs.getString("Size"),
                                           rs.getString("Color"),
                                           rs.getString("Manufacturer"),
                                           gia_str,
                                           rs.getString("Comodities"),
                                           rs.getString("Quantity"),
                                           thanhtien_str
                };

                model.addRow(row);
            }
            String Tongtien_str = currencyVN.format(Tongtien);
            lblTongtien.setText(Tongtien_str);
            con.close();//dong cac ket noi
            rs.close();
            stmt.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
        
    }  
     
    public void initLoadDataToJtableKho(){
        
        model1.setRowCount(0);//xoa toan bo cac dong hien ton tai tren ban 
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";
        try  {
            Connection con = DriverManager.getConnection(connectionUrl); 
            Statement stmt = con.createStatement();
            String SQL = "SELECT * FROM KhoGiayDep";// dat cac chuoi leng vao bien SQL
            ResultSet rs = stmt.executeQuery(SQL);//goi rs truy van vao database

            // Iterate through the data in the result set and display it.
            while (rs.next()) {
                if(!rs.getString("Quantity").equals("NULL")){
                           //thuc hien chuyen chuoi so thanh tien co dau ngat cho de nhin
                            Long gia = Long.valueOf(rs.getString("Price"));
                            Locale localeVN = new Locale("vi", "VN");
                            // Locale là đối tượng đại diện duy nhất cho các ngôn ngữ và quốc gia, khu vực
                            // khác nhau trên toàn thế giới 
                            // trong đó "vi" là ngôn ngữ và "VN" là tên quốc gia.
                            NumberFormat currencyVN = NumberFormat.getCurrencyInstance(localeVN);
                            // tạo 1 NumberFormat để định dạng số theo tiêu chuẩn của Việt Nam
                            String gia_str = currencyVN.format(gia);
                            String[] row = new String[]{
                                                rs.getString("ComodityCode"),
                                                rs.getString("Size"),
                                                rs.getString("Color"),
                                                rs.getString("Manufacturer"),
                                                gia_str,
                                                rs.getString("Comodities"),
                                                rs.getString("Quantity") 

                                };
                            model1.addRow(row);
                }

            }
            con.close();//dong cac ket noi
            rs.close();
            stmt.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
        
    }  
    public void save(){
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try { 
            
            
            Connection con0 = DriverManager.getConnection(connectionUrl); 
            String SQL0 = "SELECT * FROM XuatHang";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt0 = con0.prepareStatement(SQL0);
            ResultSet rs0 = psmt0.executeQuery();//dung rs de truy xuat lai ket qua truy van
            while(rs0.next()) {
                Connection con1 = DriverManager.getConnection(connectionUrl); 
                String SQL1 = "SELECT * FROM KhoGiayDep where ComodityCode=?";// dat cac chuoi leng vao bien SQL
                PreparedStatement psmt1 = con1.prepareStatement(SQL1);
                psmt1.setString(1, rs0.getString(1));
                ResultSet rs1 = psmt1.executeQuery();//dung rs de truy xuat lai ket qua truy van         
                //kiem tra hang co trong kho hay khong
                //neu khong xuat hang ra kho vao kho
                if(rs1.next()){//neu ma hang da ton tai trong kho thi chi cho nguoi dung sua so luong hang xuat vao khong duoc sua thong tin co san cua hang
                    int slhang = Integer.parseInt(rs1.getString(7));//lay so luong hang trong kho ra va chuyen ve kieu nguyen
                    int slxuat = Integer.parseInt(rs0.getString(7));//lay so luong hang trong bang xuat hang ra 
                    slhang = slhang - slxuat;
                    Connection con2 = DriverManager.getConnection(connectionUrl);
                    String SQL2 = "update  KhoGiayDep set Size=?,Color=?,Manufacturer=?,Price=?,Comodities=?,Quantity=?"+" where ComodityCode=?";// dat cac chuoi leng vao bien SQL
                    PreparedStatement psmt2 = con2.prepareStatement(SQL2);
                    //lay du lieu tu text field roi ghi vao o tuong ung
                    psmt2.setString(7,rs1.getString(1));
                    psmt2.setString(1,rs1.getString(2));
                    psmt2.setString(2,rs1.getString(3));
                    psmt2.setString(3,rs1.getString(4));
                    psmt2.setString(4,rs1.getString(5));
                    psmt2.setString(5,rs1.getString(6));
                    psmt2.setString(6,Integer.toString(slhang));

                    psmt2.executeUpdate();//chen du lieu vao trong CSDL
                

                    con2.close();//dong cac ket noi
                    psmt2.close();
                    
                }
                rs1.close();
                con1.close();
            }
            con0.close();//dong cac ket noi
            rs0.close();
        }
        
        
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void delete(){
        try{
            String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

            //kiem tra ma hang nguoi dung nhap co ton tai trong bang nhap hang hay chua
            Connection con4 = DriverManager.getConnection(connectionUrl); 
            String SQL4 = "DELETE FROM XuatHang";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt4 = con4.prepareStatement(SQL4);
            psmt4.executeUpdate();
            con4.close();
            psmt4.close();
            initLoadDataToJtable();
            initLoadDataToJtableKho();
        }
        catch(Exception e){
             e.printStackTrace();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnExport = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnExcel = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtMahang = new javax.swing.JTextField();
        btnExit1 = new javax.swing.JButton();
        btnDoiTK = new javax.swing.JButton();
        JPDoiTK = new javax.swing.JPanel();
        btnDoiMK = new javax.swing.JButton();
        btnDoiTT = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblKho = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblXuatHang = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        lblTongtien = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        btnExport.setBackground(new java.awt.Color(0, 255, 204));
        btnExport.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnExport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add.png"))); // NOI18N
        btnExport.setText("Xuất");
        btnExport.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnExport.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportActionPerformed(evt);
            }
        });

        btnDelete.setBackground(new java.awt.Color(0, 255, 204));
        btnDelete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete.png"))); // NOI18N
        btnDelete.setText("Xóa");
        btnDelete.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDelete.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setBackground(new java.awt.Color(0, 255, 204));
        btnEdit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/edit.png"))); // NOI18N
        btnEdit.setText("Sửa");
        btnEdit.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEdit.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnRefresh.setBackground(new java.awt.Color(0, 255, 204));
        btnRefresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/refresh.png"))); // NOI18N
        btnRefresh.setText("Làm mới");
        btnRefresh.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRefresh.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnExcel.setBackground(new java.awt.Color(0, 255, 204));
        btnExcel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnExcel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/excel.png"))); // NOI18N
        btnExcel.setText("Xuất kho");
        btnExcel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnExcel.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnExcel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcelActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Mã hàng");

        txtMahang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMahangActionPerformed(evt);
            }
        });

        btnExit1.setBackground(new java.awt.Color(0, 255, 204));
        btnExit1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnExit1.setIcon(new javax.swing.ImageIcon("E:\\nam2\\hocky1\\netbean\\NetBeansProjects\\DOAN_GIAYDEP\\test\\icon\\log-out.png")); // NOI18N
        btnExit1.setText("Đăng xuất");
        btnExit1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnExit1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnExit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExit1ActionPerformed(evt);
            }
        });

        btnDoiTK.setBackground(new java.awt.Color(0, 255, 204));
        btnDoiTK.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDoiTK.setIcon(new javax.swing.ImageIcon("E:\\nam2\\hocky1\\netbean\\NetBeansProjects\\DOAN_GIAYDEP\\test\\icon\\reset-password.png")); // NOI18N
        btnDoiTK.setText("Thay đổi tài khoản");
        btnDoiTK.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDoiTK.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDoiTK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoiTKActionPerformed(evt);
            }
        });

        JPDoiTK.setBackground(new java.awt.Color(0, 153, 153));

        btnDoiMK.setBackground(new java.awt.Color(0, 255, 204));
        btnDoiMK.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDoiMK.setText("Đổi mật khẩu");
        btnDoiMK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoiMKActionPerformed(evt);
            }
        });

        btnDoiTT.setBackground(new java.awt.Color(0, 255, 204));
        btnDoiTT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDoiTT.setText("Đổi thông tin");
        btnDoiTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoiTTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JPDoiTKLayout = new javax.swing.GroupLayout(JPDoiTK);
        JPDoiTK.setLayout(JPDoiTKLayout);
        JPDoiTKLayout.setHorizontalGroup(
            JPDoiTKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPDoiTKLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnDoiMK)
                .addGap(33, 33, 33)
                .addComponent(btnDoiTT)
                .addContainerGap())
        );
        JPDoiTKLayout.setVerticalGroup(
            JPDoiTKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnDoiMK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnDoiTT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(btnExport, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnExcel)
                .addGap(18, 18, 18)
                .addComponent(btnExit1)
                .addGap(18, 18, 18)
                .addComponent(btnDoiTK)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(JPDoiTK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtMahang))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnDelete, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
            .addComponent(btnEdit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnExcel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnRefresh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnExit1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnDoiTK, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMahang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(15, 15, 15)
                .addComponent(JPDoiTK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(btnExport, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        tblKho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã hàng", "Size", "Màu sắc", "Hãng sản xuất", "Giá", "Loại hàng", "Số lượng hàng"
            }
        ));
        tblKho.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tblKhoAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        tblKho.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblKhoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblKho);

        tblXuatHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã hàng", "Size", "Màu sắc", "Hãng sản xuất", "Giá", "Loại hàng", "Số lượng hàng"
            }
        ));
        tblXuatHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblXuatHangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblXuatHang);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Tổng tiền:");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        lblTongtien.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTongtien.setText("1884884854848444448484");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 665, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 157, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(125, 125, 125)
                                .addComponent(lblTongtien, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblTongtien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportActionPerformed
        if(txtMahang.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Ban chua nhap ma hang");
            return;
        }
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try  {
            Connection con1 = DriverManager.getConnection(connectionUrl);
            String SQL1 = "SELECT * FROM XuatHang where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt1 = con1.prepareStatement(SQL1);
            psmt1.setString(1, txtMahang.getText());
            ResultSet rs1 = psmt1.executeQuery();//dung rs de truy xuat lai ket qua truy van

            if(rs1.next()){
                JOptionPane.showMessageDialog(this, "Ma hang nay da ton tai trong bang xuat hang \nVui long kiem tra lai ma hoac chon nut sua de thay doi so luong xuat");
                return;
            }

            Connection con = DriverManager.getConnection(connectionUrl);
            String SQL = "SELECT * FROM KhoGiayDep where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            psmt.setString(1, txtMahang.getText());
            ResultSet rs = psmt.executeQuery();//dung rs de truy xuat lai ket qua truy van

             if(rs.next() && !rs.getString("Quantity").equals("NULL")) {
                if(rs.getString("Quantity").equals("0") == false){
                    FormXuatSL f1 = new FormXuatSL();
                    f1.setVisible(true);
                    f1.nhanthongtin(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
                    f1.setLocationRelativeTo(null);
                }
                else{
                    JOptionPane.showMessageDialog(this, "So luong hang cua ma hang nay da het");
                    return;
                }
            }
            else{
                JOptionPane.showMessageDialog(this, "Ma hang nay khong ton tai ");
            }
            con.close();//dong cac ket noi
            rs.close();
            txtMahang.setText("");
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnExportActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        if(txtMahang.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Ban chua chon ma hang trong bang xuat hang de xoa");
            return;
        }    
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";
         try  {
            Connection con = DriverManager.getConnection(connectionUrl);

            String SQL = "select * from XuatHang where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            //lay du lieu tu text field roi ghi vao o tuong ung
            psmt.setString(1,txtMahang.getText());
            ResultSet rs = psmt.executeQuery();
            if(!rs.next()){
                JOptionPane.showMessageDialog(this, "Ma hang nay khong co trong muc xuat hang");
                return;
            }
            con.close();//dong cac ket noi
            psmt.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }



        int dk=JOptionPane.showConfirmDialog(this,"Ban co muon xoa" , "Confirm", JOptionPane.YES_NO_OPTION);
        if(dk!=JOptionPane.YES_OPTION){
            return;
        }


        try  {
            Connection con = DriverManager.getConnection(connectionUrl);

            String SQL = "delete from XuatHang where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            //lay du lieu tu text field roi ghi vao o tuong ung
            psmt.setString(1,txtMahang.getText());

            psmt.executeUpdate();//chen du lieu vao trong CSDL
            JOptionPane.showMessageDialog(this, "Da xoa thanh cong thanh cong");
            initLoadDataToJtable();
            txtMahang.setText("");
            con.close();//dong cac ket noi
            psmt.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        if(txtMahang.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Ban chua nhap ma hang");
            return;
        }
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try {
            //kiem tra ma hang nguoi dung nhap co ton tai trong bang nhap hang hay chua
            Connection con = DriverManager.getConnection(connectionUrl);
            String SQL = "SELECT * FROM XuatHang where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            psmt.setString(1, txtMahang.getText());
            ResultSet rs = psmt.executeQuery();//dung rs de truy xuat lai ket qua truy van

            if(rs.next()) {
                Connection con1 = DriverManager.getConnection(connectionUrl);
                String SQL1 = "SELECT * FROM KhoGiayDep where ComodityCode=?";// dat cac chuoi leng vao bien SQL
                PreparedStatement psmt1 = con1.prepareStatement(SQL1);
                psmt1.setString(1, txtMahang.getText());
                ResultSet rs1 = psmt1.executeQuery();//dung rs de truy xuat lai ket qua truy van

                if(rs1.next()){//neu ma hang da ton tai trong kho thi chi cho nguoi dung sua so luong hang nhap vao khong duoc sua thong tin co san cua hang
                    FormSuaSlXuat f2 = new FormSuaSlXuat();
                    f2.nhanthongtin(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
                    f2.setVisible(true);
                    f2.setLocationRelativeTo(null);
                }

            }
            else{

            }
            con.close();//dong cac ket noi
            rs.close();
            txtMahang.setText("");

        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnEditActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        initLoadDataToJtable();
        initLoadDataToJtableKho();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnExcelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcelActionPerformed
        int kiemtra = JOptionPane.showConfirmDialog(this, "Ban da kiem tra ki thong tin cac ma hang se nhap vao kho ?");
        if(kiemtra==JOptionPane.NO_OPTION || kiemtra==JOptionPane.CANCEL_OPTION || kiemtra == JOptionPane.CLOSED_OPTION){
            return;
        }
        
        
        
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";
        //kiem tra ma hang nguoi dung nhap co ton tai trong bang nhap hang hay chua
        Random rd = new Random();  //khai bao doi tuong  random  
        try {
            Connection con_ktxuatkho  = DriverManager.getConnection(connectionUrl);
            String SQL_ktxuatkho = "SELECT * FROM XuatHang";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt_ktxuatkho = con_ktxuatkho.prepareStatement(SQL_ktxuatkho);
            ResultSet rs_ktxuatkho = psmt_ktxuatkho.executeQuery();//dung rs de truy xuat lai ket qua truy van
            
            if(!rs_ktxuatkho.next()){
                JOptionPane.showMessageDialog(this, "Ban chua dua san pham vao danh sach xuat hang");
                return;
            }
            rs_ktxuatkho.close();
            con_ktxuatkho.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        
        save();//lay hang ra khoi kho
        
           
        //neu co hang trong muc xuat kho thi thuc hien xuat phieu va xuat hang
        
        
        LocalDate localDate = LocalDate.now();
        String year = Integer.toString(localDate.getYear());//lay ra nam hien tai
        String day = Integer.toString(localDate.getDayOfMonth());//lay ra ngay hien tai
        String month = Integer.toString(localDate.getMonthValue());
        String date = day+"/"+month+"/"+year;
        int maphieu = 1;
       
        //tim xem ma phieu nao con trong thi su dung ma phieu do de lap phieu moi
        try  {
            Connection con_lapphieu = DriverManager.getConnection(connectionUrl); 
            Statement stmt_lapphieu = con_lapphieu.createStatement();
            String SQL_lapphieu = "Select *  from PhieuNhapXuat";// dat cac chuoi leng vao bien SQL
            ResultSet rs_lapphieu = stmt_lapphieu.executeQuery(SQL_lapphieu);//goi rs truy van vao database

            // Su dung ham random de random ma phieu 
            while(true){
                maphieu = rd.nextInt(1000)+1;//random ma phieu tu 1 den 1000
                int dem=0;
                while(rs_lapphieu.next()){
                    //xu ly truong hop chua co hoa don nao
                    
                    if(Integer.parseInt(rs_lapphieu.getString(1)) == maphieu) dem++;
                }
                if(dem==0) break;
            }
           
                   
                 
            String code = Integer.toString(maphieu);
                   
                   
                   
            //ghi thong tin cua dot xuat hang vao phieu nhap xuat
                   try{
                       Connection con1 = DriverManager.getConnection(connectionUrl);
                       String SQL1 = "insert into PhieuNhapXuat (CouponCode,Date,Name,Coupon,Total) values(?,?,?,?,?)";// dat cac chuoi leng vao bien SQL
                       PreparedStatement psmt1 = con1.prepareStatement(SQL1);
       
                       psmt1.setString(1,code);
                       psmt1.setString(2,date);
                       psmt1.setString(3,name);
                       psmt1.setString(4,"Xuat Kho");
                       psmt1.setString(5, Long.toString(Tongtien));
                       psmt1.executeUpdate();//chen du lieu vao trong CSDL
                       psmt1.close();
                       con1.close();
                        }
                   catch(Exception e){
                       e.printStackTrace();
                   }
            //ghi thong tin cac mat hang cua dot xuat hang vao chi tiet phieu
                    try{
                            //kiem tra nguoi dung nhap co nhap hang vao trong bang nhap hang hay chua
                            Connection con_ctp= DriverManager.getConnection(connectionUrl);
                            String SQL_ctp = "SELECT * FROM XuatHang";// dat cac chuoi leng vao bien SQL
                            PreparedStatement psmt_ctp = con_ctp.prepareStatement(SQL_ctp);
                            ResultSet rs_ctp = psmt_ctp.executeQuery();//dung rs de truy xuat lai ket qua truy van

                            while(rs_ctp.next()){
                                try{
                                        Connection con_themctp = DriverManager.getConnection(connectionUrl);
                                        String SQL_themctp = "insert into ChiTietPhieu (CouponCode,ComodityCode,Size,Color,Manufacturer,Price,Comodities,Quantity,Total) values(?,?,?,?,?,?,?,?,?)";// dat cac chuoi leng vao bien SQL
                                        PreparedStatement psmt_themctp = con_themctp.prepareStatement(SQL_themctp);

                                        psmt_themctp.setString(1,code);
                                        psmt_themctp.setString(2,rs_ctp.getString(1));
                                        psmt_themctp.setString(3,rs_ctp.getString(2));
                                        psmt_themctp.setString(4,rs_ctp.getString(3));
                                        psmt_themctp.setString(5,rs_ctp.getString(4));
                                        psmt_themctp.setString(6,rs_ctp.getString(5));
                                        psmt_themctp.setString(7,rs_ctp.getString(6));
                                        psmt_themctp.setString(8,rs_ctp.getString(7));
                                        psmt_themctp.setString(9, rs_ctp.getString(8));
                                        psmt_themctp.executeUpdate();//chen du lieu vao trong CSDL
                                        psmt_themctp.close();
                                        con_themctp.close();
                                    }
                                catch(Exception e){
                                        e.printStackTrace();
                                }
                            }
                            rs_ctp.close();
                            con_ctp.close();
                            psmt_ctp.close();
                    }
                    catch(Exception ex){
                        ex.printStackTrace();
                    }
                   
                   
                   
                   
                   
                   
                   
            //xuat file excel
                    try{
                               XSSFWorkbook wb = new XSSFWorkbook();
                               XSSFSheet sheet = wb.createSheet("danh sach");//tao ghi vao sheet danhsach
                               XSSFRow row = null;//tao mac dinh khong dong va ko o
                               Cell cell = null;
                               for(int i=0;i<tblXuatHang.getRowCount();i++){
                                   row = sheet.createRow(i);

                                   cell=row.createCell(0,CellType.STRING);
                                   cell.setCellValue( tblXuatHang.getValueAt(i, 0).toString());

                                   cell=row.createCell(1,CellType.STRING);
                                   cell.setCellValue(tblXuatHang.getValueAt(i, 1).toString());

                                   cell=row.createCell(2,CellType.STRING);
                                   cell.setCellValue(tblXuatHang.getValueAt(i, 2).toString());

                                   cell=row.createCell(3,CellType.STRING);
                                   cell.setCellValue(tblXuatHang.getValueAt(i, 3).toString());

                                   cell=row.createCell(4,CellType.STRING);
                                   cell.setCellValue(tblXuatHang.getValueAt(i, 4).toString());

                                   cell=row.createCell(5,CellType.STRING);
                                   cell.setCellValue(tblXuatHang.getValueAt(i, 5).toString());

                                   cell=row.createCell(6,CellType.STRING);
                                   cell.setCellValue(tblXuatHang.getValueAt(i, 6).toString());


                               }
                               //lam ten file va thu muc luu phieu
                               //lay nam thang ngay

                               //lam ten file
                               String phieunhap = "E:\\phieu\\"+code+"_"+".xlsx";

                               File f = new File(phieunhap);
                               try{
                                   FileOutputStream fis = new FileOutputStream(f);
                                   wb.write(fis);
                                   fis.close();
                               }
                               catch (FileNotFoundException ex){
                                   ex.printStackTrace();
                               }
                               catch (IOException ex){
                                   ex.printStackTrace();
                               }

                           }
                           catch(Exception e){
                               e.printStackTrace();
                               JOptionPane.showMessageDialog(this, "loi mo file");
                           }

                        
                  
            
            con_lapphieu.close();//dong cac ket noi
            rs_lapphieu.close();
            stmt_lapphieu.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
        JOptionPane.showMessageDialog(this, "Phieu duoc lap ngay: "+date+"\nMa phieu la: "+maphieu);
         JOptionPane.showMessageDialog(this, "Da xuat hang thanh cong");
         //sau khi da lap phieu xong thi thuc hien day hang vao kho
        //xoa bang xuat kho
        delete();
    }//GEN-LAST:event_btnExcelActionPerformed

    private void txtMahangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMahangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMahangActionPerformed

    private void tblKhoAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tblKhoAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_tblKhoAncestorAdded

    private void tblXuatHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblXuatHangMouseClicked
        // TODO add your handling code here:
        int Row = tblXuatHang.getSelectedRow();

        txtMahang.setText((String) tblXuatHang.getValueAt(Row, 0));
    }//GEN-LAST:event_tblXuatHangMouseClicked

    private void tblKhoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblKhoMouseClicked
        // TODO add your handling code here:
        int Row = tblKho.getSelectedRow();

        txtMahang.setText((String) tblKho.getValueAt(Row, 0));
    }//GEN-LAST:event_tblKhoMouseClicked

    private void btnExit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExit1ActionPerformed
        // TODO add your handling code here
        FormDN exit  = new FormDN();
        exit.setVisible(true);
        exit.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnExit1ActionPerformed

    private void btnDoiTKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoiTKActionPerformed
        // TODO add your handling code here:
        if(JPDoiTK.isVisible()==true){
            JPDoiTK.setVisible(false);
        }
        else {
            JPDoiTK.setVisible(true);
        }

    }//GEN-LAST:event_btnDoiTKActionPerformed

    private void btnDoiMKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoiMKActionPerformed
        // TODO add your handling code here:
        ThayDoiMK doimk = new ThayDoiMK(name);
        doimk.setVisible(true);
        doimk.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnDoiMKActionPerformed

    private void btnDoiTTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoiTTActionPerformed
        // TODO add your handling code here:
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try {
            //kiem tra ma hang nguoi dung nhap co ton tai trong bang nhap hang hay chua
            Connection con = DriverManager.getConnection(connectionUrl);
            String SQL = "SELECT * FROM ACCOUNT where USERNAME=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            psmt.setString(1, name);
            ResultSet rs = psmt.executeQuery();//dung rs de truy xuat lai ket qua truy van

            if(rs.next()) {
                ThayDoiTT tk = new ThayDoiTT(name);
                tk.nhanthongtin(rs.getString(2),rs.getString(5),rs.getString(6));
                tk.setVisible(true);
                tk.setLocationRelativeTo(null);

            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnDoiTTActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NhapHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NhapHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NhapHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NhapHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new XuatHangView_1(name).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel JPDoiTK;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDoiMK;
    private javax.swing.JButton btnDoiTK;
    private javax.swing.JButton btnDoiTT;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnExcel;
    private javax.swing.JButton btnExit1;
    private javax.swing.JButton btnExport;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblTongtien;
    private javax.swing.JTable tblKho;
    private javax.swing.JTable tblXuatHang;
    private javax.swing.JTextField txtMahang;
    // End of variables declaration//GEN-END:variables
}
