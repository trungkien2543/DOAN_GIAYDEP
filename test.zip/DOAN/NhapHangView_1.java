/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package DOAN;

import static DOAN.NhapHangView.name;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Locale;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author DELL
 */
public class NhapHangView_1 extends javax.swing.JFrame {
    DefaultTableModel model;
    DefaultTableModel model1;
    public static String name;
     public long Tongtien;
    /**
     * Creates new form NhapHangView
     */
    public NhapHangView_1(String name) {
        this.name = name;
        initComponents();
        String[] header = {"Mã hàng", "Size", "Màu sắc", "Hãng sản xuất", "Giá", "Loại hàng", "Số lượng"};
        String[] header1 = {"Mã hàng", "Size", "Màu sắc", "Hãng sản xuất", "Giá", "Loại hàng", "Số lượng","Thành tiền"};
        
        model=new DefaultTableModel(header1,0);
        model1=new DefaultTableModel(header, 0);
        tblNhapHang.setModel(model);
        tblKho.setModel(model1);
        initLoadDataToJtable();
        initLoadDataToJtableKho();
        this.setLocationRelativeTo(null);
        JPDoiTK.setVisible(false);
        JOptionPane.showMessageDialog(this, "Ban hay nhap ma hang truoc khi thuc hien cac thao tac Them, Xoa, Sua");
    }
    
     public void initLoadDataToJtable(){
        Tongtien= 0;
        model.setRowCount(0);//xoa toan bo cac dong hien ton tai tren ban 
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try  {
            Connection con = DriverManager.getConnection(connectionUrl); 
            Statement stmt = con.createStatement();
            String SQL = "SELECT * FROM NhapHang";// dat cac chuoi leng vao bien SQL
            ResultSet rs = stmt.executeQuery(SQL);//goi rs truy van vao database
            //thuc hien chuyen chuoi so thanh tien co dau ngat cho de nhin
               
                Locale localeVN = new Locale("vi", "VN");
                // Locale là đối tượng đại diện duy nhất cho các ngôn ngữ và quốc gia, khu vực
                // khác nhau trên toàn thế giới 
                // trong đó "vi" là ngôn ngữ và "VN" là tên quốc gia.
                NumberFormat currencyVN = NumberFormat.getCurrencyInstance(localeVN);
                // tạo 1 NumberFormat để định dạng số theo tiêu chuẩn của Việt Nam
            // Iterate through the data in the result set and display it.
            while (rs.next()) {
                Long thanhtien = Long.valueOf(rs.getString("Total"));
                Long gia = Long.valueOf(rs.getString("Price"));
                String gia_str = currencyVN.format(gia);
                String thanhtien_str = currencyVN.format(thanhtien);
                Tongtien = Tongtien+thanhtien;
                
                
                String[] row= new String[]{rs.getString("ComodityCode"),
                                           rs.getString("Size"),
                                           rs.getString("Color"),
                                           rs.getString("Manufacturer"),
                                           gia_str,
                                           rs.getString("Comodities"),
                                           rs.getString("Quantity"),
                                           thanhtien_str
                };

                model.addRow(row);
            }
            String Tongtien_str = currencyVN.format(Tongtien);
            lblTongtien.setText(Tongtien_str);
            con.close();//dong cac ket noi
            rs.close();
            stmt.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
        
    }  
     
    public void initLoadDataToJtableKho(){
        
        model1.setRowCount(0);//xoa toan bo cac dong hien ton tai tren ban 
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";
        try  {
            Connection con = DriverManager.getConnection(connectionUrl); 
            Statement stmt = con.createStatement();
            String SQL = "SELECT * FROM KhoGiayDep";// dat cac chuoi leng vao bien SQL
            ResultSet rs = stmt.executeQuery(SQL);//goi rs truy van vao database

            // Iterate through the data in the result set and display it.
            while (rs.next()) {
                if(!rs.getString("Quantity").equals("NULL")){
                           //thuc hien chuyen chuoi so thanh tien co dau ngat cho de nhin
                            Long gia = Long.valueOf(rs.getString("Price"));
                            Locale localeVN = new Locale("vi", "VN");
                            // Locale là đối tượng đại diện duy nhất cho các ngôn ngữ và quốc gia, khu vực
                            // khác nhau trên toàn thế giới 
                            // trong đó "vi" là ngôn ngữ và "VN" là tên quốc gia.
                            NumberFormat currencyVN = NumberFormat.getCurrencyInstance(localeVN);
                            // tạo 1 NumberFormat để định dạng số theo tiêu chuẩn của Việt Nam
                            String gia_str = currencyVN.format(gia);
                            String[] row = new String[]{
                                                rs.getString("ComodityCode"),
                                                rs.getString("Size"),
                                                rs.getString("Color"),
                                                rs.getString("Manufacturer"),
                                                gia_str,
                                                rs.getString("Comodities"),
                                                rs.getString("Quantity") 

                                };
                            model1.addRow(row);
                }

            }
            con.close();//dong cac ket noi
            rs.close();
            stmt.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
        
    }  
    public void save(){
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";
        //thuc hien nhap hang
        //neu trong bang nhap kho da co hang thi thuc hien nhap kho
        try {

            Connection con_dlnhap = DriverManager.getConnection(connectionUrl);
            String SQL_dlnhap = "SELECT * FROM NhapHang";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt_dlnhap = con_dlnhap.prepareStatement(SQL_dlnhap);
            ResultSet rs_dlnhap = psmt_dlnhap.executeQuery();//dung rs de truy xuat lai ket qua truy van

            while(rs_dlnhap.next()) {
                Connection con_ktkho = DriverManager.getConnection(connectionUrl);
                String SQL_ktkho = "SELECT * FROM KhoGiayDep where ComodityCode=?";// dat cac chuoi leng vao bien SQL
                PreparedStatement psmt_ktkho = con_ktkho.prepareStatement(SQL_ktkho);
                psmt_ktkho.setString(1, rs_dlnhap.getString(1));

                ResultSet rs_ktkho = psmt_ktkho.executeQuery();//dung rs de truy xuat lai ket qua truy van
                //kiem tra hang co trong kho hay khong
                //neu co chi cap nhat so luong hang
                //neu khong them hang moi vao kho
                if(rs_ktkho.next()){//neu ma hang da ton tai trong kho thi chi cho nguoi dung sua so luong hang nhap vao khong duoc sua thong tin co san cua hang
                    if(rs_ktkho.getString("Quantity").equals("NULL")){
                        Connection con_nhapsl = DriverManager.getConnection(connectionUrl);
                        String SQL_nhapsl = "update  KhoGiayDep set Size=?,Color=?,Manufacturer=?,Price=?,Comodities=?,Quantity=? "+" where ComodityCode=?";// dat cac chuoi leng vao bien SQL
                        PreparedStatement psmt_nhapsl = con_nhapsl.prepareStatement(SQL_nhapsl);
                        //lay du lieu tu text field roi ghi vao o tuong ung
                        psmt_nhapsl.setString(7,rs_dlnhap.getString(1));
                        psmt_nhapsl.setString(1,rs_dlnhap.getString(2));
                        psmt_nhapsl.setString(2,rs_dlnhap.getString(3));
                        psmt_nhapsl.setString(3,rs_dlnhap.getString(4));
                        psmt_nhapsl.setString(4,rs_dlnhap.getString(5));
                        psmt_nhapsl.setString(5,rs_dlnhap.getString(6));
                        psmt_nhapsl.setString(6,rs_dlnhap.getString(7));

                        psmt_nhapsl.executeUpdate();//chen du lieu vao trong CSDL

                        con_nhapsl.close();//dong cac ket noi
                        psmt_nhapsl.close();
                    }
                    else{//neu ma cac gia tri khac null tuc la chua bi xoa di cap nhat lai so luong nhap vao
                        int slhang = Integer.parseInt(rs_ktkho.getString(7));//lay so luong hang trong kho ra va chuyen ve kieu nguyen
                        int slnhap = Integer.parseInt(rs_dlnhap.getString(7));//lay so luong hang trong bang nhap hang ra
                        slhang = slnhap + slhang;
                        Connection con_nhapsl = DriverManager.getConnection(connectionUrl);
                        String SQL_nhapsl = "update  KhoGiayDep set Size=?,Color=?,Manufacturer=?,Price=?,Comodities=?,Quantity=? "+" where ComodityCode=?";// dat cac chuoi leng vao bien SQL
                        PreparedStatement psmt_nhapsl = con_nhapsl.prepareStatement(SQL_nhapsl);
                        //lay du lieu tu text field roi ghi vao o tuong ung
                        psmt_nhapsl.setString(7,rs_dlnhap.getString(1));
                        psmt_nhapsl.setString(1,rs_dlnhap.getString(2));
                        psmt_nhapsl.setString(2,rs_dlnhap.getString(3));
                        psmt_nhapsl.setString(3,rs_dlnhap.getString(4));
                        psmt_nhapsl.setString(4,rs_dlnhap.getString(5));
                        psmt_nhapsl.setString(5,rs_dlnhap.getString(6));
                        psmt_nhapsl.setString(6,Integer.toString(slhang));

                        psmt_nhapsl.executeUpdate();//chen du lieu vao trong CSDL

                        con_nhapsl.close();//dong cac ket noi
                        psmt_nhapsl.close();
                    }

                }
                else{//neu ma hang khong ton tai trong kho thi cho nguoi dung sua thong tin cua hang
                    Connection con_nhaptt = DriverManager.getConnection(connectionUrl);
                    String SQL_nhaptt = "insert into KhoGiayDep(ComodityCode,Size,Color,Manufacturer,Price,Comodities,Quantity) values(?,?,?,?,?,?,?)";// dat cac chuoi leng vao bien SQL
                    PreparedStatement psmt_nhaptt = con_nhaptt.prepareStatement(SQL_nhaptt);
                    //lay du lieu tu text field roi ghi vao o tuong ung
                    psmt_nhaptt.setString(1,rs_dlnhap.getString(1));
                    psmt_nhaptt.setString(2,rs_dlnhap.getString(2));
                    psmt_nhaptt.setString(3,rs_dlnhap.getString(3));
                    psmt_nhaptt.setString(4,rs_dlnhap.getString(4));
                    psmt_nhaptt.setString(5,rs_dlnhap.getString(5));
                    psmt_nhaptt.setString(6,rs_dlnhap.getString(6));
                    psmt_nhaptt.setString(7,rs_dlnhap.getString(7));

                    psmt_nhaptt.executeUpdate();//chen du lieu vao trong CSDL
                    con_nhaptt.close();//dong cac ket noi
                    psmt_nhaptt.close();
                }

                rs_ktkho.close();
                con_ktkho.close();
                psmt_ktkho.close();
            }
            con_dlnhap.close();//dong cac ket noi
            psmt_dlnhap.close();
            rs_dlnhap.close();

        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void delete(){
        try{
            String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

            //kiem tra ma hang nguoi dung nhap co ton tai trong bang nhap hang hay chua
            Connection con4 = DriverManager.getConnection(connectionUrl); 
            String SQL4 = "DELETE FROM NhapHang";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt4 = con4.prepareStatement(SQL4);
            psmt4.executeUpdate();
            con4.close();
            psmt4.close();
            initLoadDataToJtable();
            initLoadDataToJtableKho();
        }
        catch(Exception e){
             e.printStackTrace();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalFrame1 = new javax.swing.JInternalFrame();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblKho = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblNhapHang = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btnAdd = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnExcel = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtMahang = new javax.swing.JTextField();
        btnExit1 = new javax.swing.JButton();
        btnDoiTK = new javax.swing.JButton();
        JPDoiTK = new javax.swing.JPanel();
        btnDoiMK = new javax.swing.JButton();
        btnDoiTT = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        lblTongtien = new javax.swing.JLabel();

        jInternalFrame1.setVisible(true);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));

        tblKho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã hàng", "Size", "Màu sắc", "Hãng sản xuất", "Giá", "Loại hàng", "Số lượng hàng"
            }
        ));
        tblKho.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblKhoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblKho);

        tblNhapHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã hàng", "Size", "Màu sắc", "Hãng sản xuất", "Giá", "Loại hàng", "Số lượng hàng"
            }
        ));
        tblNhapHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNhapHangMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblNhapHang);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        btnAdd.setBackground(new java.awt.Color(0, 255, 204));
        btnAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add.png"))); // NOI18N
        btnAdd.setText("Thêm");
        btnAdd.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAdd.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnDelete.setBackground(new java.awt.Color(0, 255, 204));
        btnDelete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete.png"))); // NOI18N
        btnDelete.setText("Xóa");
        btnDelete.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDelete.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setBackground(new java.awt.Color(0, 255, 204));
        btnEdit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/edit.png"))); // NOI18N
        btnEdit.setText("Sửa");
        btnEdit.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEdit.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnRefresh.setBackground(new java.awt.Color(0, 255, 204));
        btnRefresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/refresh.png"))); // NOI18N
        btnRefresh.setText("Làm mới");
        btnRefresh.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRefresh.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnExcel.setBackground(new java.awt.Color(0, 255, 204));
        btnExcel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnExcel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/excel.png"))); // NOI18N
        btnExcel.setText("Nhập Kho");
        btnExcel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnExcel.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnExcel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcelActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Mã hàng");

        txtMahang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMahangActionPerformed(evt);
            }
        });

        btnExit1.setBackground(new java.awt.Color(0, 255, 204));
        btnExit1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnExit1.setIcon(new javax.swing.ImageIcon("E:\\nam2\\hocky1\\netbean\\NetBeansProjects\\DOAN_GIAYDEP\\test\\icon\\log-out.png")); // NOI18N
        btnExit1.setText("Đăng xuất");
        btnExit1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnExit1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnExit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExit1ActionPerformed(evt);
            }
        });

        btnDoiTK.setBackground(new java.awt.Color(0, 255, 204));
        btnDoiTK.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDoiTK.setIcon(new javax.swing.ImageIcon("E:\\nam2\\hocky1\\netbean\\NetBeansProjects\\DOAN_GIAYDEP\\test\\icon\\reset-password.png")); // NOI18N
        btnDoiTK.setText("Thay đổi tài khoản");
        btnDoiTK.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDoiTK.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDoiTK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoiTKActionPerformed(evt);
            }
        });

        JPDoiTK.setBackground(new java.awt.Color(0, 153, 153));

        btnDoiMK.setBackground(new java.awt.Color(0, 255, 204));
        btnDoiMK.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDoiMK.setText("Đổi mật khẩu");
        btnDoiMK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoiMKActionPerformed(evt);
            }
        });

        btnDoiTT.setBackground(new java.awt.Color(0, 255, 204));
        btnDoiTT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDoiTT.setText("Đổi thông tin");
        btnDoiTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoiTTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JPDoiTKLayout = new javax.swing.GroupLayout(JPDoiTK);
        JPDoiTK.setLayout(JPDoiTKLayout);
        JPDoiTKLayout.setHorizontalGroup(
            JPDoiTKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPDoiTKLayout.createSequentialGroup()
                .addComponent(btnDoiMK)
                .addGap(18, 18, 18)
                .addComponent(btnDoiTT)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        JPDoiTKLayout.setVerticalGroup(
            JPDoiTKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPDoiTKLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(JPDoiTKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDoiTT, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDoiMK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRefresh)
                .addGap(18, 18, 18)
                .addComponent(btnExcel)
                .addGap(18, 18, 18)
                .addComponent(btnExit1)
                .addGap(18, 18, 18)
                .addComponent(btnDoiTK)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtMahang, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(JPDoiTK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnDoiTK, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnExcel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                    .addComponent(btnRefresh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnExit1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMahang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(JPDoiTK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Tổng tiền:");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        lblTongtien.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTongtien.setText("1884884854848444448484");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(201, 201, 201)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(125, 125, 125)
                                .addComponent(lblTongtien, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 771, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblTongtien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void tblNhapHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNhapHangMouseClicked
        // TODO add your handling code here:
        int Row = tblNhapHang.getSelectedRow();

        txtMahang.setText((String) tblNhapHang.getValueAt(Row, 0));
    }//GEN-LAST:event_tblNhapHangMouseClicked

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        if(txtMahang.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Ban chua nhap ma hang");
            return;
        }
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try  {
            Connection con1 = DriverManager.getConnection(connectionUrl);
            String SQL1 = "SELECT * FROM NhapHang where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt1 = con1.prepareStatement(SQL1);
            psmt1.setString(1, txtMahang.getText());
            ResultSet rs1 = psmt1.executeQuery();//dung rs de truy xuat lai ket qua truy van

            if(rs1.next()){
                JOptionPane.showMessageDialog(this, "Ma hang nay ban da dua vao bang nhap hang\n Kiem tra lai ma hang hoac chon muc Sua de Sua thong tin");
                return;
            }

            Connection con = DriverManager.getConnection(connectionUrl);
            String SQL = "SELECT * FROM KhoGiayDep where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            psmt.setString(1, txtMahang.getText());
            ResultSet rs = psmt.executeQuery();//dung rs de truy xuat lai ket qua truy van

            if(rs.next() && !rs.getString("Quantity").equals("NULL")) {
                JOptionPane.showMessageDialog(this, "Do ma hang da ton tai trong kho nen chi can nhap so luong");
                FormNhapSL f1 = new FormNhapSL();
                f1.setVisible(true);
                f1.nhanthongtin(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
                f1.setLocationRelativeTo(null);
                
            }
            else{
                FormNhapThongTin f2 = new FormNhapThongTin();
                f2.setVisible(true);
                f2.nhanthongtin(txtMahang.getText());
                f2.setLocationRelativeTo(null);

            }
            con.close();//dong cac ket noi
            rs.close();
            txtMahang.setText("");
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        if(txtMahang.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Ban chua chon ma hang trong bang nhap hang de xoa");
            return;
        }    
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";
        try  {
            Connection con = DriverManager.getConnection(connectionUrl);

            String SQL = "select * from NhapHang where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            //lay du lieu tu text field roi ghi vao o tuong ung
            psmt.setString(1,txtMahang.getText());
            ResultSet rs = psmt.executeQuery();
            if(!rs.next()){
                JOptionPane.showMessageDialog(this, "Ma hang nay khong co trong muc nhap hang");
                return;
            }
            con.close();//dong cac ket noi
            psmt.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
        
        
        
        
        int dk=JOptionPane.showConfirmDialog(this,"Ban co muon xoa" , "Confirm", JOptionPane.YES_NO_OPTION);
        if(dk!=JOptionPane.YES_OPTION){
            return;
        }


        try  {
            Connection con = DriverManager.getConnection(connectionUrl);

            String SQL = "delete from NhapHang where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            //lay du lieu tu text field roi ghi vao o tuong ung
            psmt.setString(1,txtMahang.getText());

            psmt.executeUpdate();//chen du lieu vao trong CSDL
            JOptionPane.showMessageDialog(this, "Da xoa thanh cong thanh cong");
            initLoadDataToJtable();
            txtMahang.setText("");
            con.close();//dong cac ket noi
            psmt.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        if(txtMahang.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Ban chua nhap ma hang");
            return;
        }
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try {
            //kiem tra ma hang nguoi dung nhap co ton tai trong bang nhap hang hay chua
            Connection con = DriverManager.getConnection(connectionUrl);
            String SQL = "SELECT * FROM NhapHang where ComodityCode=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            psmt.setString(1, txtMahang.getText());
            ResultSet rs = psmt.executeQuery();//dung rs de truy xuat lai ket qua truy van

            if(rs.next()) {
                Connection con1 = DriverManager.getConnection(connectionUrl);
                String SQL1 = "SELECT * FROM KhoGiayDep where ComodityCode=?";// dat cac chuoi leng vao bien SQL
                PreparedStatement psmt1 = con1.prepareStatement(SQL1);
                psmt1.setString(1, txtMahang.getText());
                ResultSet rs1 = psmt1.executeQuery();//dung rs de truy xuat lai ket qua truy van

                if(rs1.next()){//neu ma hang da ton tai trong kho thi chi cho nguoi dung sua so luong hang nhap vao khong duoc sua thong tin co san cua hang
                    FormSuaSl f2 = new FormSuaSl();
                    f2.nhanthongtin(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
                    f2.setVisible(true);
                    f2.setLocationRelativeTo(null);
                    JOptionPane.showMessageDialog(this, "Do ma hang nay da ton tai trong kho nen ban chi duoc sua so luong hang nhap vao");
                }
                else{//neu ma hang khong ton tai trong kho thi cho nguoi dung sua thong tin cua hang
                    FormSuaThongTin f1 = new FormSuaThongTin();
                    f1.nhanthongtin(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
                    f1.setVisible(true);
                    f1.setLocationRelativeTo(null);
                    JOptionPane.showMessageDialog(this, "Do ma hang nay chua ton tai trong kho nen ban duoc sua cac thong tin khac cua ma");
                }

            }
            else{
                JOptionPane.showMessageDialog(this,"Ban chua them ma hang nay voa danh sach nhap hang");
            }
            con.close();//dong cac ket noi
            rs.close();
            txtMahang.setText("");

        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        initLoadDataToJtable();
        initLoadDataToJtableKho();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnExcelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcelActionPerformed
       int kiemtra = JOptionPane.showConfirmDialog(this, "Ban da kiem tra ki thong tin cac ma hang se nhap vao kho ?");
        if(kiemtra==JOptionPane.NO_OPTION || kiemtra==JOptionPane.CANCEL_OPTION || kiemtra == JOptionPane.CLOSED_OPTION){
            return;
        }
        
        
        
       String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";
       Random rd = new Random();//khoi tao doi tuong random
       try{

            //kiem tra ma hang nguoi dung nhap co ton tai trong bang nhap hang hay chua
            Connection con_ktnhapkho = DriverManager.getConnection(connectionUrl);
            String SQL_ktnhapkho = "SELECT * FROM NhapHang";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt_ktnhapkho = con_ktnhapkho.prepareStatement(SQL_ktnhapkho);
            ResultSet rs_ktnhapkho = psmt_ktnhapkho.executeQuery();//dung rs de truy xuat lai ket qua truy van

            if(!rs_ktnhapkho.next()){
                JOptionPane.showMessageDialog(this, "Ban chua chon hang de nhap kho");
                return;
            }
            rs_ktnhapkho.close();
            con_ktnhapkho.close();
            psmt_ktnhapkho.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
       
       
       
       save();//dua hang vao kho   
       
        



        //ghi chi tiet thong tin phieu vao co so du lieu
        LocalDate localDate = LocalDate.now();
        String year = Integer.toString(localDate.getYear());//lay ra nam hien tai
        String day = Integer.toString(localDate.getDayOfMonth());//lay ra ngay hien tai
        String month = Integer.toString(localDate.getMonthValue());
        String date = day+"/"+month+"/"+year;
        int maphieu = 1;
        String code;
        
        //tim xem ma phieu nao con trong thi su dung ma phieu do de lap phieu moi

        try  {
            Connection con_lapphieu = DriverManager.getConnection(connectionUrl); 
            Statement stmt_lapphieu = con_lapphieu.createStatement();
            String SQL_lapphieu = "Select *  from PhieuNhapXuat";// dat cac chuoi leng vao bien SQL
            ResultSet rs_lapphieu = stmt_lapphieu.executeQuery(SQL_lapphieu);//goi rs truy van vao database

            // Su dung ham random de random ma phieu 
            while(true){
                maphieu = rd.nextInt(1000)+1;//random ma phieu tu 1 den 1000
                int dem=0;
                while(rs_lapphieu.next()){
                    //xu ly truong hop chua co hoa don nao
                    
                    if(Integer.parseInt(rs_lapphieu.getString(1)) == maphieu) dem++;
                }
                if(dem==0) break;
            }
                   code = Integer.toString(maphieu);
                   //ghi thong tin nhap hang vao phieu nhap hang
                    try{
                        Connection con1 = DriverManager.getConnection(connectionUrl);
                        String SQL1 = "insert into PhieuNhapXuat (CouponCode,Date,Name,Coupon,Total) values(?,?,?,?,?)";// dat cac chuoi leng vao bien SQL
                        PreparedStatement psmt1 = con1.prepareStatement(SQL1);

                        psmt1.setString(1,code);
                        psmt1.setString(2,date);
                        psmt1.setString(3,name);
                        psmt1.setString(4,"Nhap Kho");
                        psmt1.setString(5,Long.toString(Tongtien));
                        psmt1.executeUpdate();//chen du lieu vao trong CSDL
                        psmt1.close();
                        con1.close();
                         }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                    
                    
                    
                    //dua thong tin chi tiet cac mat hang cua dot nhap hang nay vao bang chi tiet phieu
                    try{
                            //kiem tra nguoi dung nhap co nhap hang vao trong bang nhap hang hay chua
                            Connection con_ctp= DriverManager.getConnection(connectionUrl);
                            String SQL_ctp = "SELECT * FROM NhapHang";// dat cac chuoi leng vao bien SQL
                            PreparedStatement psmt_ctp = con_ctp.prepareStatement(SQL_ctp);
                            ResultSet rs_ctp = psmt_ctp.executeQuery();//dung rs de truy xuat lai ket qua truy van

                            while(rs_ctp.next()){
                                try{
                                        Connection con_themctp = DriverManager.getConnection(connectionUrl);
                                        String SQL_themctp = "insert into ChiTietPhieu (CouponCode,ComodityCode,Size,Color,Manufacturer,Price,Comodities,Quantity,Total) values(?,?,?,?,?,?,?,?,?)";// dat cac chuoi leng vao bien SQL
                                        PreparedStatement psmt_themctp = con_themctp.prepareStatement(SQL_themctp);

                                        psmt_themctp.setString(1,code);
                                        psmt_themctp.setString(2,rs_ctp.getString(1));
                                        psmt_themctp.setString(3,rs_ctp.getString(2));
                                        psmt_themctp.setString(4,rs_ctp.getString(3));
                                        psmt_themctp.setString(5,rs_ctp.getString(4));
                                        psmt_themctp.setString(6,rs_ctp.getString(5));
                                        psmt_themctp.setString(7,rs_ctp.getString(6));
                                        psmt_themctp.setString(8,rs_ctp.getString(7));
                                         psmt_themctp.setString(9,rs_ctp.getString(8));
                                        psmt_themctp.executeUpdate();//chen du lieu vao trong CSDL
                                        psmt_themctp.close();
                                        con_themctp.close();
                                    }
                                catch(Exception e){
                                        e.printStackTrace();
                                }
                            }
                            rs_ctp.close();
                            con_ctp.close();
                            psmt_ctp.close();
                    }
                    catch(Exception ex){
                        ex.printStackTrace();
                    }
                    
                    //xuat file excel
                        try{
                               XSSFWorkbook wb = new XSSFWorkbook();
                               XSSFSheet sheet = wb.createSheet("danh sach");//tao ghi vao sheet danhsach
                               XSSFRow row = null;//tao mac dinh khong dong va ko o
                               Cell cell = null;
                               for(int i=0;i<tblNhapHang.getRowCount();i++){
                                   row = sheet.createRow(i);

                                   cell=row.createCell(0,CellType.STRING);
                                   cell.setCellValue( tblNhapHang.getValueAt(i, 0).toString());

                                   cell=row.createCell(1,CellType.STRING);
                                   cell.setCellValue(tblNhapHang.getValueAt(i, 1).toString());

                                   cell=row.createCell(2,CellType.STRING);
                                   cell.setCellValue(tblNhapHang.getValueAt(i, 2).toString());

                                   cell=row.createCell(3,CellType.STRING);
                                   cell.setCellValue(tblNhapHang.getValueAt(i, 3).toString());

                                   cell=row.createCell(4,CellType.STRING);
                                   cell.setCellValue(tblNhapHang.getValueAt(i, 4).toString());

                                   cell=row.createCell(5,CellType.STRING);
                                   cell.setCellValue(tblNhapHang.getValueAt(i, 5).toString());

                                   cell=row.createCell(6,CellType.STRING);
                                   cell.setCellValue(tblNhapHang.getValueAt(i, 6).toString());

                               }
                               //lam ten file va thu muc luu phieu
                               //lay nam thang ngay

                               //lam ten file
                               String phieunhap = "E:\\phieu\\"+code+"_"+".xlsx";

                               File f = new File(phieunhap);
                               try{
                                   FileOutputStream fis = new FileOutputStream(f);
                                   wb.write(fis);
                                   fis.close();
                               }
                               catch (FileNotFoundException ex){
                                   ex.printStackTrace();
                               }
                               catch (IOException ex){
                                   ex.printStackTrace();
                               }
                           }
                           catch(Exception e){
                               e.printStackTrace();
                               JOptionPane.showMessageDialog(this, "loi mo file");
                           }

                  
            
            con_lapphieu.close();//dong cac ket noi
            rs_lapphieu.close();
            stmt_lapphieu.close();
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
        JOptionPane.showMessageDialog(this, "Phieu duoc lap ngay"+date+"\nMa phieu la: "+maphieu);
        JOptionPane.showMessageDialog(this, "Da nhap hang thanh cong");
        //sau khi da lap phieu xong thi thuc hien day hang vao kho
        //xoa bang nhap kho
        delete();
    }//GEN-LAST:event_btnExcelActionPerformed

    private void txtMahangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMahangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMahangActionPerformed

    private void tblKhoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblKhoMouseClicked
        // TODO add your handling code here:
        int Row = tblKho.getSelectedRow();

        txtMahang.setText((String) tblKho.getValueAt(Row, 0));
    }//GEN-LAST:event_tblKhoMouseClicked

    private void btnExit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExit1ActionPerformed
        // TODO add your handling code here
        FormDN exit  = new FormDN();
        exit.setVisible(true);
        exit.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_btnExit1ActionPerformed

    private void btnDoiTKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoiTKActionPerformed
        // TODO add your handling code here:
        if(JPDoiTK.isVisible()==true){
            JPDoiTK.setVisible(false);
        } 
        else {
            JPDoiTK.setVisible(true);
        }
      
    }//GEN-LAST:event_btnDoiTKActionPerformed

    private void btnDoiMKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoiMKActionPerformed
        // TODO add your handling code here:
        ThayDoiMK doimk = new ThayDoiMK(name);
        doimk.setVisible(true);
        doimk.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnDoiMKActionPerformed

    private void btnDoiTTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoiTTActionPerformed
        // TODO add your handling code here:
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=QLGiayDep;user=sa;password=123456;"+"encrypt=true;trustServerCertificate=true;sslProtocol=TLSv1.2;";

        try {
            //kiem tra ma hang nguoi dung nhap co ton tai trong bang nhap hang hay chua
            Connection con = DriverManager.getConnection(connectionUrl);
            String SQL = "SELECT * FROM ACCOUNT where USERNAME=?";// dat cac chuoi leng vao bien SQL
            PreparedStatement psmt = con.prepareStatement(SQL);
            psmt.setString(1, name);
            ResultSet rs = psmt.executeQuery();//dung rs de truy xuat lai ket qua truy van

            if(rs.next()) {
                ThayDoiTT tk = new ThayDoiTT(name);
                tk.nhanthongtin(rs.getString(2),rs.getString(5),rs.getString(6));
                tk.setVisible(true);
                tk.setLocationRelativeTo(null);
               
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnDoiTTActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NhapHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NhapHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NhapHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NhapHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NhapHangView_1(name).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel JPDoiTK;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDoiMK;
    private javax.swing.JButton btnDoiTK;
    private javax.swing.JButton btnDoiTT;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnExcel;
    private javax.swing.JButton btnExit1;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblTongtien;
    private javax.swing.JTable tblKho;
    private javax.swing.JTable tblNhapHang;
    private javax.swing.JTextField txtMahang;
    // End of variables declaration//GEN-END:variables
}
